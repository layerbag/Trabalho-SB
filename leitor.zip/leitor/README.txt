Para rodar o programa, execute:

  ./leitor < prog.blp
